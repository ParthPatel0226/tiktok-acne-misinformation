# EDA & Statistical Analysis — Complete Report
## TikTok Acne Misinformation Detection | 731 Videos × 55 Features

---

## 1. DATA OVERVIEW
- **Shape:** 731 rows × 55 columns
- **Duplicates:** 0
- **Missing:** transcript_summary (9.4%), transcript (7.5%), hashtags (5.3%), video_duration (2.6%), Missed_info (2.1%)
- **Variable Types:** 7 continuous, 2 discrete, 6 ordinal, 24 nominal, 3 binary, 1 date, 14 text

## 2. TARGET DISTRIBUTION
| Label | Count | % |
|-------|-------|---|
| no | 351 | 48.0% |
| yes | 326 | 44.6% |
| not_sure | 54 | 7.4% |

**Class balance:** Nearly balanced between yes/no. not_sure is minor class (7.4%).

## 3. CONTINUOUS FEATURES — Key Stats
| Feature | Mean | Median | Skewness | Kurtosis |
|---------|------|--------|----------|----------|
| views | 1.62M | 365K | 10.85 | 171.19 |
| likes | 93.7K | 11.2K | 16.46 | 325.57 |
| comments | 459 | 109 | 14.13 | 261.27 |
| shares | 4,315 | 559 | 21.30 | 501.27 |
| engagement_rate | 4.58% | 3.53% | 3.88 | 35.09 |
| creator_followers | 1.14M | 268K | 4.75 | 22.21 |
| video_duration | 69.3s | 45.5s | 9.91 | 157.29 |

**All engagement metrics are extremely right-skewed** — log transformation recommended for ML.

## 4. CORRELATION (Numeric × Numeric)
- **views ↔ likes: 0.91** — near duplicate, consider dropping one
- **comments ↔ shares: 0.89** — near duplicate
- **views ↔ comments: 0.73** — strong
- **engagement_rate** poorly correlated with raw counts (0.11-0.20)
- **creator_followers** weakly correlated with everything (-0.04 to 0.18)

## 5. CHI-SQUARE TESTS (Categorical × Target)
| Feature | χ² | p-value | Cramér's V | Significance |
|---------|-----|---------|------------|-------------|
| claim_type | 297.2 | <0.001 | 0.451 | *** STRONGEST |
| claim_accuracy | 194.0 | <0.001 | 0.364 | *** |
| treatment_type | 130.7 | <0.001 | 0.299 | *** |
| evidence_present | 128.6 | <0.001 | 0.297 | *** |
| skin_condition_type | 101.5 | <0.001 | 0.263 | *** |
| creator_motivation | 91.3 | <0.001 | 0.250 | *** |
| creator_type | 82.8 | <0.001 | 0.238 | *** |
| outcome_type | 40.5 | <0.001 | 0.167 | *** |
| video_format | 32.5 | <0.001 | 0.149 | *** |
| unrealistic_claim_flag | 28.2 | <0.001 | 0.196 | *** |
| before_after_claim | 8.3 | 0.016 | 0.106 | * |
| creator_gender | 2.2 | 0.700 | 0.039 | ns |

## 6. ANOVA (Numeric × Target)
| Feature | F-stat | p-value | Kruskal H | Sig |
|---------|--------|---------|-----------|-----|
| creator_followers | 4.68 | 0.010 | 26.62 | ** |
| views | 1.67 | 0.190 | 7.44 | * (KW) |
| comments | 1.34 | 0.261 | 11.79 | ** (KW) |
| likes | 2.11 | 0.122 | 5.72 | ns |
| shares | 0.97 | 0.379 | 5.57 | ns |
| engagement_rate | 0.38 | 0.682 | 0.69 | ns |
| video_duration | 0.38 | 0.682 | 5.54 | ns |

**Key finding:** creator_followers is the ONLY numeric feature significant in ANOVA. Kruskal-Wallis (non-parametric) catches views and comments as significant.

## 7. ORDINAL × TARGET (Kruskal-Wallis)
| Feature | H-stat | p-value | Sig |
|---------|--------|---------|-----|
| intent_clarity | 96.70 | <0.001 | *** |
| label_confidence | 79.44 | <0.001 | *** |
| skin_severity | 5.19 | 0.075 | ns |

## 8. ORDINAL × ORDINAL (Spearman)
- intent_clarity ↔ label_confidence: ρ=0.519 (moderate-strong)
- skin_severity uncorrelated with both

## 9. NUMERIC × ORDINAL (Spearman)
- creator_followers ↔ intent_clarity: ρ=0.118 (p=0.002) **
- engagement_rate ↔ skin_severity: ρ=-0.076 (p=0.04) *
- views ↔ skin_severity: ρ=0.080 (p=0.03) *

## 10. PCA
- PC1 (37.6%): views/likes/comments/shares — engagement cluster
- PC2 (14.4%): video_shot_complexity/No._people_video/creator_followers
- **7 components needed for 95% variance** — no strong reduction possible
- 2D projection shows partial separation between yes/no labels

## 11. GEOGRAPHIC
| Country | Misinfo Rate | n |
|---------|-------------|---|
| United States | 29.0% | 403 |
| India | 48.7% | 39 |
| South Korea | 57.8% | 45 |
| unknown | 74.2% | 155 |

## 12. OUTLIERS
| Feature | Outliers | % |
|---------|----------|---|
| shares | 95 | 13.0% |
| likes | 90 | 12.3% |
| views | 77 | 10.5% |
| comments | 73 | 10.0% |
| video_duration | 56 | 7.9% |
| creator_followers | 41 | 5.6% |
| engagement_rate | 27 | 3.7% |

---

## KEY TAKEAWAYS FOR ML

1. **Best predictors of misinfo (by Cramér's V):** claim_type (0.451), claim_accuracy (0.364), treatment_type (0.299), evidence_present (0.297)
2. **Drop or combine:** views↔likes (r=0.91), comments↔shares (r=0.89) — multicollinearity
3. **Log-transform:** all engagement metrics (extreme skewness >10)
4. **Only significant numeric feature:** creator_followers (ANOVA p=0.01)
5. **Gender does NOT predict misinfo** — non-significant
6. **Engagement rate does NOT predict misinfo** — non-significant (surprising finding)
7. **PCA shows no clean separation** — 7 components for 95%, meaning features are diverse (good for ML)
8. **Class imbalance:** minor issue with not_sure (7.4%) — use class weights or SMOTE

---

## DEEP ANALYSIS — ADDITIONAL FINDINGS

### 13. NORMALITY TESTS (Shapiro-Wilk)
ALL continuous features are NOT normally distributed (all p<0.001).
Non-parametric tests (Mann-Whitney, Kruskal-Wallis) are more appropriate than ANOVA.

### 14. MANN-WHITNEY U (yes vs no, pairwise)
| Feature | U-stat | p-value | Median Diff | Sig |
|---------|--------|---------|-------------|-----|
| creator_followers | 45,095 | <0.001 | 284,244 | *** |
| comments | 49,012 | 0.001 | 70 | ** |
| views | 51,450 | 0.023 | 163,600 | * |
| shares | 52,102 | 0.044 | 262 | * |
| video_duration | 48,696 | 0.024 | 9 sec | * |
| likes | 52,424 | 0.060 | 3,980 | ns (borderline) |
| engagement_rate | 59,222 | 0.430 | 0 | ns |

### 15. ADDITIONAL SIGNIFICANT CATEGORICAL × TARGET
| Feature | χ² | Cramér's V | Sig |
|---------|-----|------------|-----|
| country_origin | 217.3 | 0.386 | *** — 2nd STRONGEST |
| condition_recurrence | 65.7 | 0.212 | *** |
| creator_age_range | 40.0 | 0.165 | *** |
| condition_duration | 35.6 | 0.156 | *** |
| side_effects | 29.7 | 0.143 | ** |
| time_to_result_claim | 18.5 | 0.112 | * |

### 16. ADDITIONAL NON-SIGNIFICANT
condition_extent (V=0.030), sponsored_content (V=0.046), affiliate_link_present (V=0.055), face_visibility (V=0.081), indoor_outdoor (V=0.069), creator_race_visual (V=0.088)

### 17. TEXT LENGTH — STRONGEST NUMERIC PREDICTOR
- transcript_length: Kruskal H=293.6, p<0.001 ***
- Misinfo YES median: 125 chars
- Accurate NO median: 1,074 chars
- **Accurate videos have 8.6x longer transcripts**
- has_transcript × misinfo: χ²=73.9, p<0.001

### 18. BEFORE/AFTER DEEP (RQ2)
- BA engagement: 4.56% vs non-BA: 4.59% — Mann-Whitney p=0.438 (NO premium)
- BA misinfo rate: 52.1% vs non-BA: 40.9% — BA videos are MORE misinformative

### 19. POST-HOC (creator_followers)
- no vs yes: p<0.001 (median 447K vs 163K)
- no vs not_sure: p=0.002 (median 447K vs 101K)
- yes vs not_sure: p=0.638 (not significant)

### 20. COMPLETE FEATURE RANKING (Cramér's V, all 24 categorical)
1. claim_type: 0.451 ***
2. country_origin: 0.386 ***
3. claim_accuracy: 0.364 ***
4. treatment_type: 0.299 ***
5. evidence_present: 0.297 ***
6. skin_condition_type: 0.263 ***
7. creator_motivation: 0.250 ***
8. creator_type: 0.238 ***
9. condition_recurrence: 0.212 ***
10. unrealistic_claim_flag: 0.196 ***
11. outcome_type: 0.167 ***
12. creator_age_range: 0.165 ***
13. condition_duration: 0.156 ***
14. video_format: 0.149 ***
15. side_effects: 0.143 **
16. time_to_result_claim: 0.112 *
17. before_after_claim: 0.106 *
18-24: all non-significant (gender, race, sponsored, affiliate, indoor/outdoor, face, extent)

